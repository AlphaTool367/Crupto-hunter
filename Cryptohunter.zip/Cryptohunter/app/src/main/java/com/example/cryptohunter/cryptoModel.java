package com.example.cryptohunter;

public class cryptoModel {
}
