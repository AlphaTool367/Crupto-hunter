package com.example.cryptohunter;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.cryptohunter.databinding.ActivityMainBinding;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private CryptoAdapter adapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        
        setupRecyclerView();
        loadCryptoData();
    }
    
    private void setupRecyclerView() {
        adapter = new CryptoAdapter();
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);
    }
    
    private void loadCryptoData() {
        binding.textView.setText("Loading Crypto Data...");
        
        CryptoApiService apiService = RetrofitClient.getApiService();
        Call<List<CryptoModel>> call = apiService.getCryptoList("usd", "market_cap_desc", 20, 1, false);
        
        call.enqueue(new Callback<List<CryptoModel>>() {
            @Override
            public void onResponse(Call<List<CryptoModel>> call, Response<List<CryptoModel>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter.setData(response.body());
                    binding.textView.setText("Top 20 Cryptocurrencies");
                } else {
                    showError("Data load nahi hua!");
                }
            }
            
            @Override
            public void onFailure(Call<List<CryptoModel>> call, Throwable t) {
                showError("Error: " + t.getMessage());
                // Dummy data load karein agar API fail ho
                loadDummyData();
            }
        });
    }
    
    private void loadDummyData() {
        // Agar API kaam nahi kare to dummy data
        List<CryptoModel> dummyList = java.util.Arrays.asList(
            new CryptoModel("1", "Bitcoin", "BTC", 65000.0, 2.5),
            new CryptoModel("2", "Ethereum", "ETH", 3500.0, -1.2),
            new CryptoModel("3", "Binance Coin", "BNB", 420.0, 0.8)
        );
        adapter.setData(dummyList);
        binding.textView.setText("Offline Mode - Dummy Data");
    }
    
    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
