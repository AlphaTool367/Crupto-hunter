package com.example.cryptohunter;

public class CryptoModel {
    private String id;
    private String name;
    private String symbol;
    private double price;
    private double change24h;
    private double marketCap;
    
    public CryptoModel(String id, String name, String symbol, double price, double change24h) {
        this.id = id;
        this.name = name;
        this.symbol = symbol;
        this.price = price;
        this.change24h = change24h;
    }
    
    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getSymbol() { return symbol; }
    public double getPrice() { return price; }
    public double getChange24h() { return change24h; }
    public double getMarketCap() { return marketCap; }
    
    // Setters
    public void setPrice(double price) { this.price = price; }
    public void setChange24h(double change24h) { this.change24h = change24h; }
}
