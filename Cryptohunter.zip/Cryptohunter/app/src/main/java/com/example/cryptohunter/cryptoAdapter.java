package com.example.cryptohunter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.cryptohunter.databinding.ItemCryptoBinding;
import java.util.ArrayList;
import java.util.List;

public class CryptoAdapter extends RecyclerView.Adapter<CryptoAdapter.CryptoViewHolder> {
    
    private List<CryptoModel> cryptoList = new ArrayList<>();
    
    public void setData(List<CryptoModel> list) {
        this.cryptoList = list;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public CryptoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemCryptoBinding binding = ItemCryptoBinding.inflate(
            LayoutInflater.from(parent.getContext()), parent, false
        );
        return new CryptoViewHolder(binding);
    }
    
    @Override
    public void onBindViewHolder(@NonNull CryptoViewHolder holder, int position) {
        holder.bind(cryptoList.get(position));
    }
    
    @Override
    public int getItemCount() {
        return cryptoList.size();
    }
    
    static class CryptoViewHolder extends RecyclerView.ViewHolder {
        private final ItemCryptoBinding binding;
        
        public CryptoViewHolder(ItemCryptoBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
        
        public void bind(CryptoModel crypto) {
            binding.tvName.setText(crypto.getName());
            binding.tvSymbol.setText(crypto.getSymbol());
            binding.tvPrice.setText("$" + String.format("%.2f", crypto.getPrice()));
            binding.tvChange.setText(String.format("%.2f%%", crypto.getChange24h()));
            
            // Price up ya down ke hisaab se color change
            if (crypto.getChange24h() >= 0) {
                binding.tvChange.setTextColor(0xFF4CAF50); // Green
            } else {
                binding.tvChange.setTextColor(0xFFF44336); // Red
            }
        }
    }
}
